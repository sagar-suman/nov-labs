import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  someForm:any;
  ngOnInit(): void {
   
this.someForm=new FormGroup({
  "NAME":new FormControl('',Validators.compose([Validators.required,Validators.pattern(/^[A-Za-z]+$/)])),
  "EMAIL":new FormControl('',Validators.compose([Validators.required,Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)])),
  "PHONE":new FormControl('',Validators.compose([Validators.required,Validators.pattern(/^\d{10}$/)]))

})

  }
  title = 'multiplication_table';
  tableFlag:boolean=false;
  inputValue!:number;
  res:any[]=[];
  onValueInput(ev:any){
    let data=ev.target.value ;
    if(data.length==0)
    this.res=[];

  }
  onButtonClick(){
   

    for(let i=1;i<=10;i++){
      let temp={
        inputNumber:this.inputValue,
        operation:'*',
        multiplier:i,
        result:this.inputValue*i,
      }
      this.res.push(temp);
    }

    this.tableFlag=true;

  }
  submithandler(){
    console.log(this.someForm.getRawValue())
  }
}
